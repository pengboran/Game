/**
 * Created by user-pc on 2017/5/1.
 */
$(function(){
    $('.common:nth-last-child(2)').css('display','none');
    var select=$('#select');
    select.on('change',function(){
        var option=select.find('option:selected').text();
        if(option =="修改服装"){
            $('.common:nth-last-child(2)').css('display','block');
        }else{
            $('.common:nth-last-child(2)').css('display','none');
        }
    });

    function selec(fun){
        if(select.find('option:selected').text()=="增加服装"){
            fun("height",'weight','chest','sleeve','cuf','src','../php/add_shirt.php');
        }else if(select.find('option:selected').text()=="删除服装"){
            fun("height",'weight','chest','sleeve','cuf','src','../php/delete_shirt.php');
        }else{
            fun("height",'weight','chest','sleeve','cuf','src','../php/edit_shirt.php');
        }
        return fun;
    }


    $('.button').on('click',function(e){
        e.preventDefault();
        selec(contr);
    });
    function  contr(h,w,c,s,f,sr,name) {
        var height=$("#height").find('option:selected').text();
        var weight=$("#weight").find('option:selected').text();
        var chest=$("#chest").find('option:selected').text();
        var sleeve=$("#sleeve").find('option:selected').text();
        var cuf=$("#cuf").find('option:selected').text();
        var src="../wearImg/shirt/"+$("#src").val()+".jpg";
        var obj={};
        obj[h]=height;
        obj[w]=weight;
        obj[c]=chest;
        obj[s]=sleeve;
        obj[f]=cuf;
        obj[sr]=src;
        var arg=arguments;
        if(arg[arg.length-1].indexOf('edit')>0){
            var edit="../wearImg/shirt/"+$("#edit").val()+".jpg";
            obj['edit']=edit;
        }
        $.ajax({
            type:"POST",
            url:name,
            data:obj,
            contentType:"application/x-www-form-urlencoded",
            dataType:"text",
            async:"true",
            timeout:1000,
            error:function(){
                alert("操作失败！");
            },
            success:function(data){
                if(data =="ok"){
                    alert("操作成功！");
                }else if(data =="no"){
                    alert("操作失败！");
                }
            }
        })
    }
});