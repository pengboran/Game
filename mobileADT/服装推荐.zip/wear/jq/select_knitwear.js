/**
 * Created by user-pc on 2017/4/18.
 */
$(function() {
    $('.button').click(function(){
        getImg('height','weight','chest','sleeve');
    });
    function  getImg(h,w,c,s) {
        var height=$("#height").find("option:selected").text();
        var weight=$("#weight").find("option:selected").text();
        var chest=$("#chest").find("option:selected").text();
        var sleeve=$("#sleeve").find("option:selected").text();
        var obj={};
        obj[h]=height;
        obj[w]=weight;
        obj[c]=chest;
        obj[s]=sleeve;
        $.ajax({
            type:"POST",
            url:"../php/select_knitwear.php",
            data:obj,
            contentType:"application/x-www-form-urlencoded",
            dataType:"text",
            async:"true",
            timeout:1000,
            beforeSend: function () {
                $(".image img.wear").each(function () {
                    $(this).remove()
                });
                $('.spinner').css('display', 'block');
            },
            error: function () {
                alert("请求失败！");
            },
            success: function (data) {
                $('.spinner').css('display', 'none');
                $(".image").append($(data));
                $(".image .wear").each(function () {
                    $(this).css('border', '1px solid #fff')
                           .bind({
                            'mouseover': function () {
                                $(this).css('border', '1px solid #f00')
                            },
                            'mouseout':function () {
                                $(this).css('border', '1px solid #fff')
                            }
                           });
                })
            }
        })

    }
});