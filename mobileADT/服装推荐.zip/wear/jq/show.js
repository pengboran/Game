/**
 * Created by user-pc on 2017/4/20.
 */
$(function(){
    $('.button').click(function(e){
        $('.shade').css('display','block');
        e.preventDefault();
    });
    $('.hide').click(function(){
        $('.shade').css('display','none');
    });
});