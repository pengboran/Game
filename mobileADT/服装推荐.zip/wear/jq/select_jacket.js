/**
 * Created by user-pc on 2017/4/18.
 */
$(function() {
    $('.button').click(function(){
        getImg('height','weight','wear');
    });
    function  getImg(h,w,we) {
        var height=$("#height").find("option:selected").text();
        var weight=$("#weight").find("option:selected").text();
        var wear=$("#wear").find("option:selected").text();
        var obj={};
        obj[h]=height;
        obj[w]=weight;
        obj[we]=wear;
        $.ajax({
            type:"POST",
            url:"../php/select_jacket.php",
            data:obj,
            contentType:"application/x-www-form-urlencoded",
            dataType:"text",
            async:"true",
            timeout:1000,
            beforeSend: function () {
                $(".image img.wear").each(function () {
                    $(this).remove();
                });
                $('.spinner').css('display', 'block');
            },
            error: function () {
                alert("请求失败！");
            },
            success: function (data) {
                $('.spinner').css('display', 'none');
                $(".image").append($(data));
                $(".image .wear").each(function () {
                    $(this).css('border', '1px solid #fff')
                        .bind({
                           'mouseover': function () {
                                $(this).css('border', '1px solid #f00')
                           },
                            'mouseout':function () {
                                $(this).css('border', '1px solid #fff')
                           }
                        });
                })
            }
        })

    }
});