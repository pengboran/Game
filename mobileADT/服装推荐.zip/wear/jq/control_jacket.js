/**
 * Created by user-pc on 2017/5/1.
 */
$(function(){
    $('.common:nth-last-child(2)').css('display','none');
    var select=$('#select');
    select.on('change',function(){
        var option=select.find('option:selected').text();
        if(option =="修改服装"){
            $('.common:nth-last-child(2)').css('display','block');
        }else{
            $('.common:nth-last-child(2)').css('display','none');
        }
    });
    function selec(fun){
        var option=select.find('option:selected').text();
        switch (option){
            case "增加服装":
                fun("height",'weight','chest','src','../php/add_jacket.php');
                break;
            case "删除服装":
                fun("height",'weight','chest','src','../php/delete_jacket.php');
                break;
            case "修改服装":
                fun("height",'weight','chest','src','../php/edit_jacket.php');
                break;
            default:
                break;
        }
        return fun;
    }

    $('.button').on('click',function(e){
        e.preventDefault();
        selec(contr);
    });
    function  contr(h,w,we,sr,name) {
        var height=$("#height").find('option:selected').text();
        var weight=$("#weight").find('option:selected').text();
        var wear=$("#wear").find('option:selected').text();
        var src="../wearImg/jacket/"+$("#src").val()+".jpg";
        var obj={};
        obj[h]=height;
        obj[w]=weight;
        obj[we]=wear;
        obj[sr]=src;
        var arg=arguments;
        if(arg[arg.length-1].indexOf('edit')>0){
            var edit="../wearImg/jacket/"+$("#edit").val()+".jpg";
            obj['edit']=edit;
        }
        $.ajax({
            type:"POST",
            url:name,
            data:obj,
            contentType:"application/x-www-form-urlencoded",
            dataType:"text",
            async:"true",
            timeout:1000,
            error:function(){
                alert("请求失败！");
            },
            success:function(data){
                if(data =="ok"){
                    alert("操作成功！");
                }else if(data =="no"){
                    alert("操作失败！");
                }
            }
        })
    }

});