/**
 * Created by user-pc on 2017/4/30.
 */
$(function(){
    $('select:not(#select)').each(function(){
        $(this).html('');
    });
    $.ajax({
        type:"GET",
        url:"../php/update_coat.php",
        contentType:"application/x-www-form-urlencoded",
        dataType:"json",
        async:"true",
        timeout:1000,
        error:function(){
            alert("请求失败！");
        },
        success:function(data){
            var arr=[],i,len,le,new_arr=[],ar=Object.keys(data[0]),length=ar.length;
            //关于arr的存有所有select的二维数组
            for(var j=0;j<length;j++){
                arr[j]=[];
                for(i=0,len=data.length;i<len;i++){
                    arr[j].push(data[i][ar[j]]);
                }
            }

            //console.log(arr);
            //过滤arr中的重复元素
            for(j=0,le=arr.length;j<le;j++){
                new_arr[j]=[];
                for(i=0,len=arr[j].length;i<len;i++){
                    var items=arr[j][i];
                    //判断元素是否存在于new_arr中，如果不存在则插入到new_arr的最后
                    if($.inArray(items,new_arr[j])==-1) {
                        new_arr[j].push(items);
                    }
                }
            }
            //console.log(new_arr);
            var oSelect=$("select:not(#select)");
            for(j=0,le=new_arr.length;j<le;j++){
                for(i=0,len=new_arr[j].length;i<len;i++){
                    var option="<option value='"+new_arr[j][i]+"' >"+new_arr[j][i]+"</option>";
                    oSelect[j].innerHTML+=(option);
                }
            }
        }
    })
});