/**
 * Created by user-pc on 2017/5/9.
 */
window.onload=function(){
    validate.init();
};

var regTel=/^((13[0-9]{1})|159|153|156)+\d{8}$/;
var regPass=/\S{6,16}/;
var validate={
    deLet:function(){
        var input=document.querySelectorAll('.common .com .input');
        var deLe=document.querySelectorAll('.common .com .delete');
        for(var i=0,len=deLe.length;i<len;i++){
            input[i].addEventListener('input',show,false);
            deLe[i].addEventListener('click',del,false);
        }
        function show(){
            if(this.value==''){
                this.nextElementSibling.style.display='none';
                this.parentNode.nextElementSibling.innerHTML='';
            }else{
                this.nextElementSibling.style.display='inline-block';
                this.parentNode.nextElementSibling.innerHTML='';
            }
        }
        function del(){
            this.parentNode.parentNode.nextElementSibling.innerHTML='';
            this.parentNode.previousElementSibling.value='';
            this.parentNode.style.display='none';
        }
    },
    tel:function(){
        var tel=s('#telphone');
        tel.addEventListener('blur',teLe,false);
        function teLe(){
            var tValue=tel.value;
            var T = regTel.test(tValue);
            var span = tel.parentNode.nextElementSibling;
            if(tValue.length<11 || tValue.length>11){
                if(tValue==''){}else{
                    span.innerHTML="<i class='default'></i>帐号须由11位数字组成";
                }
            }else{
                if(T<=0){
                    span.innerHTML="<i class='default'></i>输入手机号错误";
                }else{
                    span.innerHTML="<i class='current'></i>"
                }
            }
        }

    },
    oldPass:function(){
        var pass=s('#oldPass');
        pass.addEventListener('blur',passTest,false);
        function passTest() {
            var pValue = pass.value;
            var P = regPass.test(pValue);
            var span = pass.parentNode.nextElementSibling;
            if (pValue.length > 16) {
                span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
            } else if (pValue.length >= 0 && pValue.length < 6) {
                if(pValue.length == 0){}else{
                    span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
                }
            } else {
                if (P < 0) {
                    span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
                } else {
                    var num=function(s){
                        var pa=/^[0-9]{6,16}$/;
                        var c=pa.exec(s);
                        if(!c) {
                            return false
                        }else{
                            return true
                        }
                    };
                    if(num(pValue)){
                        span.innerHTML ="<i class='warning'></i>密码过于简单，请重新设置"
                    }else{
                        span.innerHTML = "<i class='current'></i>";
                    }
                }
            }
        }
    },
    pass:function(){
        var pass=s('#pass');
        pass.addEventListener('blur',passTest,false);
        function passTest() {
            var pValue = pass.value;
            var P = regPass.test(pValue);
            var span = pass.parentNode.nextElementSibling;
            if (pValue.length > 16) {
                span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
            } else if (pValue.length >= 0 && pValue.length < 6) {
                if(pValue.length == 0){}else{
                    span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
                }
            } else {
                if (P < 0) {
                    span.innerHTML = "<i class='default'></i>密码须由6-16个字符组成，区分大小写";
                } else {
                    var num=function(s){
                        var pa=/^[0-9]{6,16}$/;
                        var c=pa.exec(s);
                        if(!c) {
                            return false
                        }else{
                            return true
                        }
                    };
                    if(num(pValue)){
                        span.innerHTML ="<i class='warning'></i>密码过于简单，请重新设置"
                    }else{
                        span.innerHTML = "<i class='current'></i>";
                    }
                }
            }
        }
    },
    cPass:function(){
        var cPass=s('#cpass');
        cPass.addEventListener('blur',cPassTest,false);
        function cPassTest(){
            var pass=s('#pass'),pValue = pass.value;
            var cpValue = cPass.value;
            var span = cPass.parentNode.nextElementSibling;
            if (cpValue == pValue) {
                if(pValue!=''){
                    span.innerHTML = "<i class='current'></i>";
                }
            } else {
                span.innerHTML = "<i class='default'></i>密码不一致";

            }
        }
    },
    change:function(){
        var input=document.querySelectorAll('.common .com .input');
        for(var i=0,len=input.length;i<len;i++){
            input[i].addEventListener('focus',foc,false);
            input[i].addEventListener('blur',blu,false);
        }
        function foc() {
            this.parentNode.nextElementSibling.value = '';
            this.parentNode.style.border = "1px solid blue";
        }
        function blu(){
            this.parentNode.style.border = "1px solid #ddd";
        }
    },
    edit:function(){
        /*重复密码回头修改密码时重新验证两次密码一致*/
        var cPass=s('#cpass');
        function cPassTest(){
            var pass=s('#pass'),pValue = pass.value;
            var cpValue = cPass.value;
            var span = cPass.parentNode.nextElementSibling;
            if (cpValue == pValue) {
                if(pValue!=''){
                    span.innerHTML = "<i class='current'></i>";
                }
            } else {
                span.innerHTML = "<i class='default'></i>密码不一致";

            }
        }
        cPassTest();
        var button=s('#button');
        button.addEventListener('click',riGist,false);
        function riGist(){
            var tel=s('#telphone').parentNode.nextElementSibling.firstElementChild.className,oldPass=s('#oldPass').parentNode.nextElementSibling.firstElementChild.className,passs=s('#pass').parentNode.nextElementSibling.firstElementChild.className,cPass=s('#cpass').parentNode.nextElementSibling.firstElementChild.className;
            if(tel=='current'&&oldPass=='current'&&passs=='current'&&cPass=='current'){
                var te=s('#telphone').value,oldP=s('#oldPass').value,pas=s('#pass').value;
                var xhr;
                if(window.XMLHttpRequest){
                    xhr=new XMLHttpRequest();
                }else{
                    xhr=new ActiveXObject('Microsoft.XMLHTTP')
                }
                xhr.onreadystatechange=function(){
                    if(xhr.readyState==4){
                        if(xhr.status==200||xhr.status==304){
                            console.log(xhr.responseText);
                            if(xhr.responseText.trim()=='ok'){
                                alert('修改成功!');
                                location.href='./login.html';
                            }else{
                                alert('账号不存在或密码错误!');
                            }
                        }
                    }
                };
                xhr.open("POST",'php/edit.php?telPhone='+te+'&password='+oldP+'&newPassword='+pas,true);
                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=utf-8");
                xhr.send();
            }
        }


    },
    init:function(){
        this.deLet();
        this.tel();
        this.oldPass();
        this.pass();
        this.cPass();
        this.change();
        this.edit();
    }
};