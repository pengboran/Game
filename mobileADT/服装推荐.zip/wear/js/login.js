/**
 * Created by user-pc on 2017/4/7.
 */
window.onload=function(){
    Login.init();
};

var Login={
    login:function(){
        var th=this;
        var user=s('#user'),pass=s('#pass'),button=document.querySelectorAll('.button');
        var input=document.querySelectorAll('form p .inp');
        var vali=s('.valite');
        for(var i=0,len=input.length;i<len;i++){
            input[i].addEventListener('input',show,false);
            input[i].addEventListener('focus',foCus,false);
        }
        function show(){
            this.nextElementSibling.style.display='inline-block';
            this.nextElementSibling.addEventListener('click',hiDe,false);
            if(this.value ==''){
                this.nextElementSibling.style.display='none';
            }
        }
        function hiDe(){
            this.previousElementSibling.value='';
            this.style.display='none';
        }
        function foCus(){
            this.parentNode.style.border='1px solid #e8e8e8';
            vali.className='valite vali';
        }
        for(i=0,len=button.length;i<len;i++){
            button[i].addEventListener('click',test,false);
        }
        function test(){
            var use=user.value,pas=pass.value;
            if(use==''||pas==''){
                vali.className='valite';
                if(use==''){
                    vali.lastElementChild.innerHTML='请输入用户名';
                    user.parentNode.style.border='1px solid #fa6060';
                }else{
                    vali.lastElementChild.innerHTML='请输入密码';
                    pass.parentNode.style.border='1px solid #fa6060';
                }
            }else if(use=="admin"&&pas=="123456"){
                /*管理员登录*/
                alert('管理员登录成功！');
                location.href="./manager.html";
            }else{
                /*用户登录*/
                var xhr;
                if(window.XMLHttpRequest){
                    xhr=new XMLHttpRequest();
                }else{
                    xhr=new ActiveXObject('Microsoft.XMLHTTP');
                }
                xhr.onreadystatechange=function(){
                    if(xhr.readyState==4){
                        if(xhr.status==200||xhr.status==304){
                            if(xhr.responseText.trim()=='ok'){
                                alert('用户登录成功！');
                                location.href="./select.html";
                                th.checkCookie(use,pas);
                            }else{
                                vali.className='valite';
                            }
                        }
                    }
                };
                xhr.open("POST",'php/login.php?user='+use+'&password='+pas,true);
                xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=utf-8");
                xhr.send();
            }
        }
    },
    cookie:function(){
        this.checkCookie=function(use,pas){
            var cookL=document.cookie.length;
            var cook=document.cookie;
            var u=user.getAttribute('name');
            var p=pass.getAttribute('name');
            var arr=[];
            arr.push(u,p);
            if(cookL>0){
                console.log(document.cookie);
                this.getCookie=function(){
                    function get(c_use){
                        var start=cook.indexOf(c_use + "=");
                        if (start!=-1)
                        {
                            start=start + c_use.length+1;
                            var end=cook.indexOf(";",start);
                            if (end==-1) {
                                end=cook.length;
                            }
                            return unescape(cook.substring(start,end))
                        }
                        return ""
                    }
                    console.log(get(u)+'/'+get(p));
                    var uValue=get(u);
                    var pValue=get(p);
                    if(use==uValue&&pas==pValue){
                        alert('登陆成功！');
                        location.href='./select.html';
                    }
                };
                //this.getCookie();
            }else{
                this.setCookie=function(use,password,expiredays){
                    (function(){
                        var arg=arguments;
                        var date=new Date();
                        date.setDate(date.getDate()+expiredays);
                        for(var i=0,len=arg.length;i<len-1;i++){
                            document.cookie=arr[i]+'='+escape(arg[i])+((expiredays==null)?'':';expires='+date.toGMTString())
                        }
                    })(use,password,expiredays);
                };
                this.setCookie(use,pas,30);
            }
        };
    },
    init:function(){
        this.login();
        this.cookie();
    }
};