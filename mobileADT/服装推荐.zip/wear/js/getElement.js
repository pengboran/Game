/**
 * Created by user-pc on 2017/4/18.
 */
var s=function (str){
    var st=str.slice(0,1);
    var s=str.slice(1);
    var newStr;
    if(st =="#"){
        newStr=document.getElementById(s);
    }else if(st =="."){
        newStr=document.getElementsByClassName(s)[0];
    }else{
        newStr=document.getElementsByTagName(str)[0];
    }
    return newStr;
};