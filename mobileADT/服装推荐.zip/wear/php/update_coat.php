<?php
/**
 * Created by PhpStorm.
 * User: user-pc
 * Date: 2017/4/30
 * Time: 15:07
 */
header('content-type:application/json;charset=utf8');

$conn=@mysql_connect('localhost','root','nie520nie') or die ('连接失败');
mysql_query("set names 'GBK'");
mysql_select_db('WEAR');


$sql = "select height,weight,chest from coat ";

// 查询数据到数组中
$result = mysql_query($sql,$conn);

$results = array();
while ($row = mysql_fetch_assoc($result)) {
    $results[] = $row;
}

// 将数组转成json格式
echo json_encode($results);