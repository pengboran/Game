<?php
/**
 * Created by PhpStorm.
 * User: user-pc
 * Date: 2017/5/9
 * Time: 13:44
 */
$t = $_GET['telPhone'];
$p = $_GET['password'];
$np= $_GET['newPassword'];

$conn=@mysql_connect('localhost','root','nie520nie') or die ('连接失败');
mysql_query("set names 'GBK'");
mysql_select_db('USER');

$sq= "select telphone,password from us where telphone='$t' and password='$p'";

$retval = mysql_query( $sq, $conn );
if(! $retval )
{
    echo "查询失败".mysql_error();
}else{
    $row=mysql_fetch_row($retval);
    if(!$row){
        echo 'no';
    }else{
        $sql="UPDATE us set password='$np' where telphone='$t' and password='$p'";
        $retval = mysql_query( $sql, $conn );
        if(! $retval )
        {
            echo "插入失败".mysql_error();
        }else{
            echo 'ok';
        }
    }
}

mysql_close($conn);