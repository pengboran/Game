<?php
/**
 * Created by PhpStorm.
 * User: user-pc
 * Date: 2017/5/1
 * Time: 19:29
 */
header('content-type:application/json;charset=utf8');

$conn=@mysql_connect('localhost','root','nie520nie') or die ('连接失败');
mysql_query("set names 'GBK'");
mysql_select_db('WEAR');

$data = file_get_contents("php://input",true);

parse_str($data, $arr);

$ar=array_values($arr);

$h=$ar[0];
$w=$ar[1];
$c=$ar[2];
$sr=$ar[3];

$sq="SELECT * FROM coat WHERE height='$h' AND weight='$w' AND chest='$c' AND src='$sr'";

$retval = mysql_query( $sq, $conn );
if(! $retval )
{
    echo "查询失败".mysql_error();
}else{
    $row=mysql_fetch_row($retval);
    if(!$row){
        $sql2 = "INSERT INTO coat".
            "(height,weight,chest,src)".
            "VALUES ".
            "('$h','$w','$c','$sr')";
        $retval = mysql_query( $sql2, $conn );
        if(!$retval){
            echo "插入数据失败".mysql_error();
        }
        echo 'ok';
    }else{
        echo 'no';
    }
}

mysql_close($conn);
?>