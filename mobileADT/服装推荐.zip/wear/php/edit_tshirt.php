<?php
/**
 * Created by PhpStorm.
 * User: user-pc
 * Date: 2017/5/2
 * Time: 9:04
 */
header('content-type:application/json;charset=utf8');

$conn=@mysql_connect('localhost','root','nie520nie') or die ('连接失败');
mysql_query("set names 'GBK'");
mysql_select_db('WEAR');

$data = file_get_contents("php://input",true);

parse_str($data, $arr);

$ar=array_values($arr);

$h=$ar[0];
$w=$ar[1];
$c=$ar[2];
$sr=$ar[3];
$ed=$ar[4];

$sq="SELECT * FROM tshirt WHERE height='$h' AND weight='$w' AND chest='$c' AND src='$sr'";

$retval = mysql_query( $sq, $conn );
if(! $retval )
{
    echo "查询失败".mysql_error();
}else{
    $row=mysql_fetch_row($retval);
    if(!$row){
        echo 'no';
    }else{
        $sql="SELECT * FROM tshirt WHERE height='$h' AND weight='$w' AND chest='$c' AND src='$ed'";
        $retval = mysql_query( $sql, $conn );
        if(! $retval )
        {
            echo "查询失败".mysql_error();
        }else{
            $row=mysql_fetch_row($retval);
            if(!$row){
                $sql2="UPDATE  tshirt SET src='$ed' WHERE height='$h' AND weight='$w' AND chest='$c' AND src='$sr'";
                $retval = mysql_query( $sql2, $conn );
                echo 'ok';
            }else{
                echo 'no';
            }
        }
    }
}


mysql_close($conn);