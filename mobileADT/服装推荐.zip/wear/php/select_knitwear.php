<?php
/**
 * Created by PhpStorm.
 * User: user-pc
 * Date: 2017/4/27
 * Time: 21:00
 */

$conn=@mysql_connect('localhost','root','nie520nie') or die ('连接失败');
mysql_query("set names 'GBK'");
mysql_select_db('WEAR');

$data = file_get_contents("php://input",true);

parse_str($data, $arr);

$ar=array_values($arr);

$h=$ar[0];
$w=$ar[1];
$c=$ar[2];
$s=$ar[3];

$sql1 = "SELECT src FROM knitwear WHERE height='$h' AND weight='$w' AND chest='$c' AND sleeve='$s'";

$query = mysql_query($sql1, $conn);
if (!$query) {
    echo "查询不到数据！" . mysql_error();
}

while($row=mysql_fetch_array($query)){
    $src = $row['src'];
    echo "<a href='http://www.taobao.com'><img src='".$src."' alt='抱歉，匹配不到！' class='wear' ></a>";
}

mysql_close($conn);
