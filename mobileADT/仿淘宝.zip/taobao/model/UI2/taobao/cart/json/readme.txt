﻿JSON数据

1、goodsData.json，商品详细
id           id        String
fTitle       标题                 String
fImg         图片                 String
fPrice       价格                 Float
fOldPrice    原价格            Float
fPostage     邮费                 String
fRecord      买出数量       Integer
fAddress     所在地区       String
fColor       颜色                 String
fSize        尺寸                 String
fChoose      选中                 String
fNumber      数量                 Integer
fSum         总价                 Float


2、shopData.json，店铺信息
id           id        String
fShopName    店名                 String
fLevel       等级                 Integer
fShopImg     店标                 String
fConsistent  描述相符       Float
fService     服务态度       Float
fGoodsNumber 商品数量       Integer
fFocusNumber 关注人数       Integer

3、sendData.json，配送方式信息
id           id        String
fSendName    配送方式       String
fCost        运费                 String
fState       状态                 Integer


