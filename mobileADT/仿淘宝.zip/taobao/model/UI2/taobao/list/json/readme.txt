﻿JSON数据

1、goodsData.json，商品信息
id           id           String
fShopID      店铺ID       String
fTitle       标题                         String
fImg         图片                         String
fPrice       价格                         Float
fPostage     邮费                         String
fRecord      月销量               Integer

