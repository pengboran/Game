define(function(require){
	var versionInfo = {
	  androidApp:{
	  	version:"5.3.18",
	  	changeLog:"请填写版本更新内容",
	  	downloadUrl:"http://wex5.com/apps/taobao.apk"
	  },
	  iosApp:{
	  	version:"5.3.18",
	  	changeLog:"请填写版本更新内容",
	  	downloadUrl:"itms-services:///?action=download-manifest&url=https://x.justep.com/apps/taobao.plist"
	  }
	};
	return versionInfo;
});
