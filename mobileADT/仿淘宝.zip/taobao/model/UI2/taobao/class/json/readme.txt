﻿JSON数据

1、listData.json，商品信息
id           id           String
fTitle       标题                         String
fImg         图片                         String
fPrice       价格                         Float
fPostage     邮费                         String
fRecord      销售数量               Integer



